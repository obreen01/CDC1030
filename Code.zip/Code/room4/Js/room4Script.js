//player vars
var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");

//audio var
var audioPlaying = sessionStorage.getItem("audioPlaying");

//alarm vars
var te1;
var alarmOn = 1; //either on or off

//timer vars
var te2;
var oxygen = 30; //seconds until fail
var progress = 100; //percentage of timer progress bar
var progReducer = 3.33; //starting level with 30secs '1/30 = 3.33%'
window.addEventListener('load', function() { te1 = setInterval(alarmSwitch, 1000); });
window.addEventListener('load', function(){ te2 = setInterval(countdown, 1000);});

//room vars
var hasHammer = false;
var hasKey = false;

//timer code--------------------------------------------------------------------
function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    }
    else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1/oxygen;
    x =x *100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}
//-----------------------------------------------------------------------------

function alarmSwitch() {
    if (alarmOn == 0) {
        document.getElementById("alarm").style.visibility = "visible";
        document.getElementById("alarmSound").volume = 0.1;
        document.getElementById("alarmSound").play();
        alarmOn = 1;
    }
    else {
        document.getElementById("alarm").style.visibility = "hidden";
        alarmOn = 0;
    }
}

function breakWindow() {
    console.log(pName + " You clicked the Window");
        if (hasHammer == true) {
            var windowBreak = document.getElementById("windowBreak");
            windowBreak.play();
            alert("You have shattered the window and you make your way to the final room.");
            nextPage();
        }
        else {
            alert("You may need to find something to break the window");
        }

    }
function pickupHammer() {
    console.log("You clicked on the Hammer");
    var hammer = document.getElementById("hammer");
            hammer.play();
    hasHammer=true;
    document.getElementById("Hammer").style.visibility = "hidden";
    alert("You found a Hammer. It might be off use");
}

function moveToolbox() {
    console.log("You clicked the toolbox");
    var toolbox = document.getElementById("toolbox");
            toolbox.play();
    document.getElementById("Hammer").style.visibility = "visible";
    document.getElementById("Toolbox").style.top = "700px";
    document.getElementById("Toolbox").style.left = "250px";
    document.getElementById("Toolbox").style.transform = "rotate(20deg)";
}

function moveSchoolBag(){
    console.log("You clicked the School bag");
    var schoolBag = document.getElementById("schoolBag");
            schoolBag.play();
    document.getElementById("Key").style.visibility = "visible";
    document.getElementById("Schoolbag").style.top = "700px";
    document.getElementById("Schoolbag").style.left = "764px";
    document.getElementById("Schoolbag").style.transform = "rotate(20deg)";
}
function pickupKey() {
    console.log("You clicked on a key");
    var key = document.getElementById("keySound");
            key.play();
    hasKey=true;
    document.getElementById("Key").style.visibility = "hidden";
    alert("You found a Key. It might be off use");
}

function openDoor(){
     console.log(pName + " You clicked the Door");
    var door = document.getElementById("doorSound");
            door.play();
        if (hasKey == true) {
            alert("This is the wrong key. You will have to find another way out");
            var windowBreak = document.getElementById("windowBreak");
            windowBreak.play();
            
        }
        else {
            alert("You may need to find a key for the door");
        }
}

function openBox(){
    var cardboardBox = document.getElementById("cardboardBox");
            cardboardBox.play();
    console.log(pName + " You clicked the box");
    alert("There is a note in the box stating that you will have to smash your way out of this room");          
        }      

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);
    sessionStorage.setItem("audioPlaying", audioPlaying);

    sessionStorage.setItem("messageShown", 1);     //for room 2 code

    window.location.href = "./room2.html";        //go to next page
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    sessionStorage.setItem("audioPlaying", audioPlaying);
    
    window.location.href = "./endScreen.html";        //go to next page
}

//audiocode --------------------------------------------------------
window.addEventListener("load", checkAudio, false);

function mutePage() {
    document.querySelectorAll("video, audio").forEach( elem => muteMe(elem) );
    audioPlaying = "false";
    document.getElementById("playingButton").style.visibility = "hidden";
    document.getElementById("mutedButton").style.visibility = "visible";
}

function unmutePage() {
    document.querySelectorAll("video, audio").forEach( elem => unmuteMe(elem) );
    audioPlaying = "true";
    document.getElementById("playingButton").style.visibility = "visible";
    document.getElementById("mutedButton").style.visibility = "hidden";
}

function checkAudio() {
    
    if (audioPlaying === "true") {
        unmutePage();
    }
    else if (audioPlaying == "false"){
        mutePage();
    }
}