const textElement = document.getElementById('text')
const optionButtonsElement = document.getElementById('option-buttons')

var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");

var te2;
var oxygen = sessionStorage.getItem("tmrOxygen", oxygen); //seconds until fail
var progress = sessionStorage.getItem("tmrProgress", progress); //percentage of timer progress bar
var progReducer = sessionStorage.getItem("tmrProgReducer", progReducer); //starting level with 30secs '1/30 = 3.33%'

window.addEventListener('load', function() { te2 = setInterval(countdown, 1000); });

let state = {}

function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    }
    else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1/oxygen;
    x =x *100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}

function startGame() {
    document.getElementById("btnHide").style.visibility = "hidden";
  state = {}
  showTextNode(1)
}

function showEndButton(){
    document.getElementById("btnHide").style.visibility = "visible";
}

function endGame(){
    
}

function showTextNode(textNodeIndex) {
  const textNode = textNodes.find(textNode => textNode.id === textNodeIndex)
  console.log(textElement)
  textElement.innerText = textNode.text
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild)
  }

  textNode.options.forEach(option => {
    if (showOption(option)) {
      const button = document.createElement('button')
      button.innerText = option.text
      button.classList.add('btn')
      button.addEventListener('click', () => selectOption(option))
      optionButtonsElement.appendChild(button)
    }
  })
}

function showOption(option) {
  return option.requiredState == null || option.requiredState(state)
}

function selectOption(option) {
  const nextTextNodeId = option.nextText
  if (nextTextNodeId <= 0) {
    return endGame()
  }
  if(nextTextNodeId ===999){
      return showEndButton()
  }
  state = Object.assign(state, option.setState)
  showTextNode(nextTextNodeId)
}

const textNodes = [
  {
    id: 1,
    text: 'Phew, you make it into the next room. You need to close the door behind you. Try pressing one of the buttons infront of you.',
    options: [
      {
        text: 'Blue Button',
        nextText: 2
      },
      {
        text: 'Green Button',
        nextText: 2
      }
    ]
  },
  {
    id: 2,
    text: 'The door slams closed. In front of you is a keycard and a screwdriver. You must take one. ',
    options: [
      {
        text: 'Take the screwdriver',
        setState: {driver: true},
        nextText: 3
      },
      {
        text: 'Take the keycard',
        setState: {card: true},
        nextText: 3
      },
      {
        text: 'You dont want to play by the rules, you take neither.',
        nextText: 3
      }
    ]
  },
  {
    id: 3,
    text: 'In front of you, you see three things. A door that requires a keycard to open, a rusty vent that looks like it might lead somewhere and a box with screws in it. What do you try first??',
    options: [
      {
        text: 'Try that rusty vent',
        nextText: 4
      },
      {
        text: 'Try the door.',
        requiredState: (currentState) => currentState.card,
        nextText: 5
      },
      {
        text: 'Try the box',
        requiredState: (currentState) => currentState.driver,
        nextText: 6
      }
    ]
  },
  {
    id: 4,
    text: 'You climb into the rusty vent but the vent swings closes and slices into your ankle. You are unbale to ecape out of the vent and die a slow painful death as you ankle becomes infected.',
    options: [
      {
        text: 'GAME OVER!',
        nextText: -1
      }
    ]
  },
  {
    id: 5,
    text: 'The door swings open and you get sucked out into space never to be seen again.',
    options: [
      {
        text: 'GAME OVER!',
        nextText: -1
      }
    ]
  },
  {
    id: 6,
    text: 'You open the box to find a crowbar, maybe you can use this to get out.',
    options: [
      {
        text: 'Look around the room',
        nextText: 7
      }
    ]
  },
  {
    id: 7,
    text: 'A scary creature breaks into the room from behind you.',
    options: [
      {
        text: 'Try to run',
        nextText: 8
      },
      {
        text: 'Attack it with your crowbar',
        nextText: 9
      },
      {
        text: 'Try to open the door you see in the corner of ther room',
        nextText: 10
      }
    ]
  },
  {
    id: 8,
    text: 'Your attempts to run are in vain and the monster easily catches.',
    options: [
      {
        text: 'GAME OVER!',
        nextText: -1
      }
    ]
  },
  {
    id: 9,
    text: 'The monster simply eats the crowbar out of you hand and soon after this you are also eaten.',
    options: [
      {
        text: 'GAME OVER!',
        nextText: -1
      }
    ]
  },
  {
    id: 10,
    text: 'You have escaped the monster and see some wooden planks covering a hole.',
    options: [
      {
        text: 'Use the crowbar and pull the wooden planks out of the way',
        nextText: 999
      }
    ]
}
]

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);

    window.location.href = "./plane.html"; //BARRETTS LEVEL GOES IN THE SPEACH MARKS
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    window.location.href = "./endScreen.html";        //go to next page
}

startGame()