//player vars
var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");
var oxygen = sessionStorage.getItem("tmrOxygen"); //store all timer variables
var progress = sessionStorage.getItem("tmrProgress") + 30;
var progReducer = sessionStorage.getItem("tmrProgReducer");
var ship = document.getElementById('ship');
var shipWing = document.getElementById('shipWing');
var shipWingTop = 290;
var shipTop = 250;
var shipLeft = 135;

//room vars
var hasRightWing = false;
var hasBattery = false;
var hasEngine = false;
var hasAntenna = false;
var hasScrewDriver = false;
var hasBatteryCover = false;

var audio = new Audio('Audio/planeroom/drill.wav');
// var audio = new Audio('../resources/drill.wav');
var plane = new Audio('Audio/planeroom/plane.wav');

//alarm vars
var te1;

//timer vars
var te2;

// track game state
var resolvedPuzzles = 0;
var TOTAL_PUZZLES = 4;

countdown();

window.addEventListener('load', function () {
    alert('oh no the escape pod has been damaged ! click on the parts that have been broken off. Some fixes requires multiple parts to be repair.');
    te1 = setInterval(alarmSwitch, 1000);
});
window.addEventListener('load', function () {
    te2 = setInterval(countdown, 1000);
});

function alarmSwitch() {
    document.getElementById("alarm").classList.toggle('alarmOn');
}

//timer code--------------------------------------------------------------------
function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    } else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1 / oxygen;
    x = x * 100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}
//-----------------------------------------------------------------------------

function onRightWingPieceClicked(e) {
    if (!hasRightWing) {
        audio.currentTime = 0;
        audio.play();
        removeElmentById('rightWingArea');
        removeElmentById('wing');
        showElement('shipWing');
        resolvedPuzzles++;
        alert('Right wing found');

        processWinningState();
    }
}

function onBatteryClicked(e) {
    if (!hasBattery) {
        audio.currentTime = 0;
        audio.play();
        removeElmentById('battery');
        hasBattery = true;
        alert('Battery found');
        processBatteryState();
    }
}

function onBatteryCoverClicked(e) {
    if (!hasBatteryCover) {
        audio.currentTime = 0;
        audio.play();
        removeElmentById('batteryCover');
        hasBatteryCover = true;
        alert('Battery panel found');
        processBatteryState();
    }
}

function processBatteryState(){
    if (hasBattery && hasBatteryCover) {
        audio.currentTime = 0;
        audio.play();
        removeElmentById('batteryArea');
        showElement('batteryCoverOnShip');
        resolvedPuzzles++;
        processWinningState();
    }
   
}

function onEngineClicked(e) {
    if (!hasEngine) {
        audio.currentTime = 0;
        audio.play();
        var source = getSourceFromEvent(e);
        source.style.display = 'none';
        hasEngine = true;
        alert('Engine core found');
        processEngineState();
    }
}

function onScrewDriverClicked(e) {
    if (!hasScrewDriver) {
        audio.currentTime = 0;
        audio.play();
        var source = getSourceFromEvent(e);
        source.style.display = 'none';
        hasScrewDriver = true;
        alert('Screw driver wing found');
        processEngineState();
    }
}

function processEngineState(){
    if (hasEngine && hasScrewDriver) {
        audio.currentTime = 0;
        audio.play();
        removeElmentById('engineArea');
        showElement('engineOnShip');
        resolvedPuzzles++;
        processWinningState();
    }   
}



function onAntennaClicked(e) {
    if (!hasAntenna) {
        alert('Antenna found');
        removeElmentById('antenna');
        audio.play();
        showElement('antennaOnShip');
        resolvedPuzzles++;
        hasAntenna = true;
        processWinningState();
    }
}


//-------------------------------------------------

function onRightWingSpotClicked(e) {

    if (!hasRightWing) {
        alert('seems like something is missing here');
    }
}

function onBatteryCoverSpotClicked(e) {

    if (!hasBattery) {
        alert('A power source is missing, is there any power equipment nearby!');
    } else if (!hasBatteryCover) {
        alert("This needs to be covered befored take off, there must be a panel around here?");
    }
}

function onEngineSpotClicked(e) {

    if (!hasEngine) {
        alert('The engine has its core missing!');
    } else if (!hasScrewDriver) {
        alert('Need a tool to attach the core to engine!');
    }
}


function onAntennaSpotClicked(e) {
    if (!hasAntenna) {
        alert('There must be a missing part around here to catch the signals');
    }
}

function processWinningState() {
    
    if (resolvedPuzzles == TOTAL_PUZZLES){
        plane.play();
        animatePlane(quad,draw,2000, completeGame);
        // nextPage();
    }
}

function nextPage() {
    pScore = oxygen;
    pWinner = true;
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    // sessionStorage.setItem("plyrHScore", Math.max(pHighScr, pScore));

    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);
    window.location.href = "./endScreen.html";        //go to next page
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    setPlayCount();
    window.location.href = "./endScreen.html";        //go to next page
}

function completeGame(){
    alert('Well done! you have finished the game');
    nextPage();
}

function setPlayCount(){
    var playCount = parseInt(sessionStorage.getItem("playCount")) || 0;
    playCount += 1;
    sessionStorage.setItem("playCount", playCount);
}

function hasWon() {
    return resolvedPuzzles == TOTAL_PUZZLES;
}


function getSourceFromEvent(e) {
    return event.target || event.srcElement;
}

function showElement(id) {
    var x = document.getElementById(id);
    x.style.display = "block";
}

function hideElement(id) {
    var x = document.getElementById(id);
    x.style.display = "none";
}

function removeElmentById(id){
    document.getElementById(id).remove();
}

function toggleVisbility(id) {
    var x = document.getElementById(id);

    if (x.style.display === "none" || x.style.display === "") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

function animatePlane(timing, draw, duration, action){
    document.getElementById('batteryCoverOnShip').style.display = 'none';
    document.getElementById('engineOnShip').style.display = 'none';
    document.getElementById('antennaOnShip').style.display = 'none';
    ship.src = 'images/planeroom/space_ship.png';
    var start = performance.now();
    requestAnimationFrame(function planAnim(time){
        var timeFraction = (time - start) / duration;
        if (timeFraction > 1) timeFraction = 1;

        var progress = timing(timeFraction);        

        draw(progress);

        if (timeFraction < 1) {
            requestAnimationFrame(planAnim);
          }else if(action){
            action();
          }
    });
}

function quad(timeFraction) {
    return Math.pow(timeFraction, 2);
}

function timing(timeFraction) {
    return timeFraction*100;
  }

function  draw(progress) {
    if (shipTop-(progress * shipTop) > 100){
        ship.style.top = shipTop-(progress * shipTop)+'px';
        shipWing.style.top = (shipWingTop - shipTop)+shipTop-(progress * shipTop)+'px';
    }
  }

// animatePlane(quad,draw,2000, completeGame);
// animatePlane(quad,draw,2000, null);
