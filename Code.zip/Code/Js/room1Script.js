//player vars
var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");

//audio var
var audioPlaying = sessionStorage.getItem("audioPlaying");

//room vars
var hasHelmet = false;
var hasKey = false;

//alarm vars
var te1;
var alarmOn = 1; //either on or off

//timer vars
var te2;
var oxygen = 30; //seconds until fail
var progress = 100; //percentage of timer progress bar
var progReducer = 3.33; //starting level with 30secs '1/30 = 3.33%'

window.addEventListener('load', function() { te1 = setInterval(alarmSwitch, 1000); });
window.addEventListener('load', function() { te2 = setInterval(countdown, 1000); });

function alarmSwitch() {
    if (alarmOn == 0) {
        document.getElementById("alarm").style.visibility = "visible";
        document.getElementById("alarmSound").volume = 0.1;
        document.getElementById("alarmSound").play();
        alarmOn = 1;
    }
    else {
        document.getElementById("alarm").style.visibility = "hidden";
        alarmOn = 0;
    }
}

//timer code--------------------------------------------------------------------
function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    }
    else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1/oxygen;
    x =x *100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}
//-----------------------------------------------------------------------------

function tryDoor() {
    console.log(pName + " You clicked the door");
    if (hasHelmet == true) {
        if (hasKey == true) {
            var doorSound = document.getElementById("doorSound");
            doorSound.play();
            do  {
                alert("The door unlocks and you step out into the hallway.");
                nextPage();
            } while (doorSound.currentTime==doorSound.duration)
        }
        else {
            alert("The power is off in the ship, you'll need to find a manual way to unlock the door.");
        }
    }
    else {
        alert("You're running out of oxygen fast! Maybe try finding something to help you breathe before trying to leave.");
    }
}

function pickupHelmet() {
    console.log("You clicked the helmet");
    hasHelmet=true;
    document.getElementById("helmet").style.visibility = "hidden";
    document.getElementById("helmetSound").play();
    alert("Great job "+pName+", you put your space suit on and can finally breathe easily. The oxygen system must be broken on the space craft and you only have one oxygen tank left!");
    oxygen = oxygen + 270;  //give the player 4.5mins of oxygen
    progReducer = getProgReducer();  //find the percentage to reduce the timer bar by with the new oxygen level
    progress = 100; //reset progress percentage to full
    document.getElementById("progress").style.width = "100%"; //reset the timer bar to 100%
}

function pickupKey() {
    console.log("You clicked the key");
    hasKey=true;
    document.getElementById("key").style.visibility = "hidden";
    document.getElementById("keySound").play();
    alert("You found a key. It must unlock something in this room.");
}

function movePot() {
    document.getElementById("plant").onclick = "";
    console.log("You clicked the pot");
    document.getElementById("key").style.visibility = "visible";
    document.getElementById("plant").style.top = "325px";
    document.getElementById("plant").style.left = "55px";
    document.getElementById("plant").style.transform = "rotate(20deg)";
    document.getElementById("plantSound").play();
    
}

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);
    sessionStorage.setItem("audioPlaying", audioPlaying);

    sessionStorage.setItem("messageShown", 1);     //for room 2 code

    window.location.href = "./room4.html";        //go to next page
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    sessionStorage.setItem("audioPlaying", audioPlaying);
    
    window.location.href = "./endScreen.html";        //go to next page
}

//audiocode --------------------------------------------------------
window.addEventListener("load", checkAudio, false);

function muteMe(elem) {
    elem.muted = true;
    elem.pause();
}

function unmuteMe(elem) {
    elem.muted = false;
}

function mutePage() {
    document.querySelectorAll("video, audio").forEach( elem => muteMe(elem) );
    audioPlaying = "false";
    document.getElementById("playingButton").style.visibility = "hidden";
    document.getElementById("mutedButton").style.visibility = "visible";
}

function unmutePage() {
    document.querySelectorAll("video, audio").forEach( elem => unmuteMe(elem) );
    audioPlaying = "true";
    document.getElementById("playingButton").style.visibility = "visible";
    document.getElementById("mutedButton").style.visibility = "hidden";
}

function checkAudio() {
    
    if (audioPlaying === "true") {
        unmutePage();
    }
    else if (audioPlaying == "false"){
        mutePage();
    }
}