//player vars
var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");

//audio var
var audioPlaying = sessionStorage.getItem("audioPlaying");

//alarm vars
var te1;
var alarmOn = 1; //either on or off

//timer vars
var te2;
var oxygen = sessionStorage.getItem("tmrOxygen", oxygen); //seconds until fail
var progress = sessionStorage.getItem("tmrProgress", progress); //percentage of timer progress bar
var progReducer = sessionStorage.getItem("tmrProgReducer", progReducer); //starting level with 30secs '1/30 = 3.33%'

//message var
var shown = sessionStorage.getItem("messageShown", shown);

window.addEventListener('load', function() { te1 = setInterval(alarmSwitch, 1000); });
window.addEventListener('load', function() { te2 = setInterval(countdown, 1000); });
window.setTimeout(roomEntered, 1000);

function alarmSwitch() {
    if (alarmOn == 0) {
        document.getElementById("alarm").style.visibility = "visible";
        document.getElementById("alarmSound").volume = 0.1;
        document.getElementById("alarmSound").play();
        alarmOn = 1;
    }
    else {
        document.getElementById("alarm").style.visibility = "hidden";
        alarmOn = 0;
    }
}

//timer code--------------------------------------------------------------------
function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    }
    else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1/oxygen;
    x =x *100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}
//-----------------------------------------------------------------------------

function roomEntered() {
    if (shown == 1){
        alert("Well done " + pName + "! You have successfully made it out of the sleeping quaters, now you must made you way trough the sealed doors up ahead. Luckily for you it seems that the backup generator has turned on!");
        shown = 0;
    }
}

function openKeypad() {
    "use strict";
    nextPage();
    window.location.href = "./keypad.html";
}

function openSign() {
    "use strict";
    nextPage();
    window.location.href = "./puzzle.html";
}

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);
    sessionStorage.setItem("messageShown", shown);
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    sessionStorage.setItem("audioPlaying", audioPlaying);
    
    window.location.href = "./endScreen.html";        //go to next page
}


//audiocode --------------------------------------------------------
window.addEventListener("load", checkAudio, false);

function muteMe(elem) {
    elem.muted = true;
    elem.pause();
}

function unmuteMe(elem) {
    elem.muted = false;
}

function mutePage() {
    document.querySelectorAll("video, audio").forEach( elem => muteMe(elem) );
    audioPlaying = "false";
    document.getElementById("playingButton").style.visibility = "hidden";
    document.getElementById("mutedButton").style.visibility = "visible";
}

function unmutePage() {
    document.querySelectorAll("video, audio").forEach( elem => unmuteMe(elem) );
    audioPlaying = "true";
    document.getElementById("playingButton").style.visibility = "visible";
    document.getElementById("mutedButton").style.visibility = "hidden";
}

function checkAudio() {
    
    if (audioPlaying === "true") {
        unmutePage();
    }
    else if (audioPlaying == "false"){
        mutePage();
    }
}