//player vars
var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");

//timer vars
var te2;
var oxygen = sessionStorage.getItem("tmrOxygen", oxygen); //seconds until fail
var progress = sessionStorage.getItem("tmrProgress", progress); //percentage of timer progress bar
var progReducer = sessionStorage.getItem("tmrProgReducer", progReducer); //starting level with 30secs '1/30 = 3.33%'

window.addEventListener('load', function() { te2 = setInterval(countdown, 1000); });

//timer code--------------------------------------------------------------------
function countdown() {
    if (oxygen > 0) {
        oxygen--;
        document.getElementById("value").innerHTML = oxygen;
        document.getElementById("progress").style.width = getProgress() + "%";
    }
    else {
        document.getElementById("value").innerHTML = "DEAD";
        endGame();
    }
}

function getProgReducer() {
    var x = 1/oxygen;
    x =x *100;
    return x;
}

function getProgress() {
    progress = progress - progReducer;
    return progress;
}
//-----------------------------------------------------------------------------


function closeSign() {
    "use strict";
    nextPage();
    window.location.href = "./elevator.html";
}

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    
    sessionStorage.setItem("tmrOxygen", oxygen);       //store all timer variables
    sessionStorage.setItem("tmrProgress", progress);
    sessionStorage.setItem("tmrProgReducer", progReducer);
}

function endGame() {
    pScore = oxygen;
    pWinner = "false";
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    sessionStorage.setItem("audioPlaying", audioPlaying);
    
    window.location.href = "./endScreen.html";        //go to next page
}