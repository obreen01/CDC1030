var pName = sessionStorage.getItem("plyrName");
var pGender = sessionStorage.getItem("plyrGender");
var pScore = sessionStorage.getItem("plyrScore");     
var pWinner = sessionStorage.getItem("plyrWinner");
var pHighScr = sessionStorage.getItem("plyrHScore");
var pSurvived;

//audio var
var audioPlaying = sessionStorage.getItem("audioPlaying");

//audiocode --------------------------------------------------------
window.addEventListener("load", checkAudio, false);

function muteMe(elem) {
    elem.muted = true;
    elem.pause();
}

function unmuteMe(elem) {
    elem.muted = "false";
}

function mutePage() {
    document.querySelectorAll("video, audio").forEach( elem => muteMe(elem) );
    audioPlaying = "false";
    document.getElementById("playingButton").style.visibility = "hidden";
    document.getElementById("mutedButton").style.visibility = "visible";
}

function unmutePage() {
    document.querySelectorAll("video, audio").forEach( elem => unmuteMe(elem) );
    audioPlaying = "true";
    document.getElementById("playingButton").style.visibility = "visible";
    document.getElementById("mutedButton").style.visibility = "hidden";
}

function checkAudio() {
    if (audioPlaying === "true") {
        unmutePage();
    }
    else if(audioPlaying === "false") {
        mutePage();
    }
}


window.addEventListener("load", checkWinner, false);

function checkWinner(){
    if (pName === null) {
        pName="error";
        pWinner=false;
        document.getElementById("retryButton").style.visibility="hidden";
    }
    if (pWinner === "true") {
        setWinner();
    }
    else {
        setLoser();
    }
    
    highScore();
}

function setWinner(){
    document.getElementById("resultLabel").innerHTML = "Mission Complete:";
    document.getElementById("resultLabel").style.color = "greenyellow";
    document.getElementById("resultLabel").style.fontSize = "52px";
    document.getElementById("resultLabel").style.left = "12px";
    
    document.getElementById("gameContainer").style.backgroundImage = 'url("./Images/endScreen/escapePodEarthSmall.png")';
    
    document.getElementById("scoreLabel").innerHTML = "Score: " + pScore;
    pSurvived = "did survive";
    playerDetails();
}

function setLoser(){
    document.getElementById("resultLabel").innerHTML = "Mission Failed:";
    document.getElementById("resultLabel").style.color = "red";
    document.getElementById("resultLabel").style.fontSize = "56px";
    document.getElementById("resultLabel").style.left = "28px";
    
    document.getElementById("gameContainer").style.backgroundImage = 'url(./Images/endScreen/deadAstronaut.png)';
    
    document.getElementById("scoreLabel").innerHTML = "Score: 0";
    pSurvived = "did not survive";
    playerDetails();
}

function playerDetails() {
    pPronoun = getPronoun();
    document.getElementById("playersLabel").innerHTML = pName + "- " + pPronoun + " " + pSurvived;
}

function getPronoun() {
    if (pGender == "male") {
        return "He";
    }
    else if (pGender == "female") {
        return "She";
    }
    else {
        return "they";
    }
}

function highScore(){    
    if (pScore > pHighScr) {
        document.getElementById("hScoreLabel").style.visibility = "visible";
        document.getElementById("hScoreLabel").innerHTML = "New High Score!";
        pHighScr = pScore;
    }
    else {   
        document.getElementById("hScoreLabel").style.visibility = "visible";
        document.getElementById("hScoreLabel").innerHTML = "High Score: " + pHighScr;
    }
    
    if (pScore == 0 && pHighScr == 0) {
        document.getElementById("hScoreLabel").style.visibility = "hidden";
    }
}

function mainMenu() {
    sessionStorage.clear();
    window.location.href = "./index.html";
}

function restartGame() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", 0);         //reset score
    sessionStorage.setItem("plyrWinner", false);    //reset winner
    sessionStorage.setItem("plyrHScore", pHighScr);
    console.log("Player saved.");
    sessionStorage.setItem("audioPlaying", audioPlaying);
    window.location.href = "./room1.html";        //go to next page
}
