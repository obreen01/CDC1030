var pName = "player1";    //placeholder player name
var pGender = "other"; //placeholder player gender
var pScore = 0;       //players score
var pWinner = false;  //has the player won?
var pHighScr = 0      //players high score

var audioPlaying = "true"; //is audio playing?

//audiocode --------------------------------------------------------
function muteMe(elem) {
    elem.muted = true;
    elem.pause();
}

function unmuteMe(elem) {
    elem.muted = false;
}

function mutePage() {
    document.querySelectorAll("video, audio").forEach( elem => muteMe(elem) );
    audioPlaying = false;
    document.getElementById("playingButton").style.visibility = "hidden";
    document.getElementById("mutedButton").style.visibility = "visible";
}

function unmutePage() {
    document.querySelectorAll("video, audio").forEach( elem => unmuteMe(elem) );
    audioPlaying = true;
    document.getElementById("playingButton").style.visibility = "visible";
    document.getElementById("mutedButton").style.visibility = "hidden";
}


function startGame() {
    console.log("Player saved. Name="+pName+" Gender="+pGender);
    nextPage();
}

function savePlayer() {
    pName = document.getElementById("pNameBox").value;  //set name
    
    var radios = document.getElementsByName("gender");
    for (var i = 0, length = radios.length; i < length; i++) {   //loop to check which gender button was pressed
        if (radios[i].checked) {
            pGender = radios[i].value;
            // only one radio can be logically checked, don't check the rest
            console.log("Player saved. Name="+pName+" Gender="+pGender);
            break;
        }
    }
    
    alert("Player saved. Name= "+pName+" Gender= "+pGender);
}

function nextPage() {
    sessionStorage.setItem("plyrName", pName);      //Store all player's variables to transfer to next page.
    sessionStorage.setItem("plyrGender", pGender);
    sessionStorage.setItem("plyrScore", pScore);
    sessionStorage.setItem("plyrWinner", pWinner);
    sessionStorage.setItem("plyrHScore", pHighScr);
    console.log("Player saved.");

    sessionStorage.setItem("audioPlaying", audioPlaying);

    window.location.href = "./room1.html";        //go to next page
}
